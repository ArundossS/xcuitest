//
//  NScrollView.h
//  Restaurant
//
//  Created by TechFlitter on 27/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NScrollView : UIScrollView

@end

//
//  PaymentHomeViewController.h
//  ExperiBank
//
//  Created by TechFlitter on 01/01/13.
//  Copyright (c) 2013 Experitest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentHomeViewController : UIViewController
{
    IBOutlet UIScrollView *scrollView;
    IBOutlet UIButton *makePaymentButton;
    IBOutlet UIWebView *balanceWebView;
    IBOutlet UIButton *logoutButton;
}

@end

//
//  AppDelegate.h
//  ExperiBank
//
//  Created by TechFlitter on 31/12/12.
//  Copyright (c) 2012 Experitest. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LoginViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) LoginViewController *loginViewController;

@end
